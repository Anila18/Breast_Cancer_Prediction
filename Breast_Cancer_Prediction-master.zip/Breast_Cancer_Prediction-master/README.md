# Breast_Cancer_Prediction
Application of Ensemble Machine Learning classification approach, with SVM, Logistic Regression, Decision Trees as sub Models.
